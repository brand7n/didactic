/*  
    This file is part of The Didactic PDP-8 Assembler
    Copyright (C) 2002 Toby Thain, toby@telegraphics.com.au

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by  
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License  
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "asm.h"
#include "fnv.h"

/* following constant should be prime. for a list of prime numbers, 
   see http://www.utm.edu/research/primes/lists/small/1000.txt */
#define TABLE_SIZE_PRIME 509
#define HASH(s) (fnv_32_str(s,FNV1_32_INIT) % TABLE_SIZE_PRIME)

struct sym_rec *hash_table[TABLE_SIZE_PRIME];
extern struct sym_rec predefs[];

void init_symtab(){
	struct sym_rec *p;
	int i;

	for(i=TABLE_SIZE_PRIME;i--;)
		hash_table[i] = 0;
	for(p=predefs;p->name;p++){
		if(debug && lookup(p->name))
			printf("!!!! duplicate predefined symbol: %s\n",p->name);
		p->flags |= F_ASSIGNED;
		insert(p);
	}
	cpu_initsyms();
}

void dump_symbols(){
	struct sym_rec *p;
	int i;
	puts("\nsymbol table:");
	for(i=0;i<TABLE_SIZE_PRIME;i++)
		if(hash_table[i]){
			for(p=hash_table[i];p;p=p->next)
				if( /* debug || */ (p->flags & F_USER) ){
					printf("  %-8s",p->name);
					if(p->flags & F_ASSIGNED){
						printf(" = %#5o",p->value);
						if(p->lineno)
							printf(" (line %3d)\n",p->lineno);
						else putchar('\n');
					}
					else
						puts(" (unassigned)");
				}
		}
}


struct sym_rec *lookup(char *s){
	struct sym_rec *p;
	int idx = HASH(s);
	/* DPRINTF("# lookup \"%s\" hash=%5d\n",s,idx); */
	for(p=hash_table[idx];p;p=p->next)
		if(!strcmp(s,p->name))
			return p;
	return 0; /* not found */
}
void insert(struct sym_rec *p){
	int idx = HASH(p->name);
	p->next = hash_table[idx];
	hash_table[idx] = p;
	/* DPRINTF("# insert symbol [%5d] \"%s\"\n",idx,p->name);*/
}
void expunge(){
	int i;
	struct sym_rec *p,*q;
	for(i=0;i<TABLE_SIZE_PRIME;i++){
		for(p = hash_table[i];p;p=q){
			DPRINTF(" deleting symbol \"%s\"\n",p->name);
			q = p->next;
			if(p->flags & F_USER)
				free(p);
		}
		hash_table[i] = 0;
	}
}
