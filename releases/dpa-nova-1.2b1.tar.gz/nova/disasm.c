/*  
    This file is part of The Didactic PDP-8 Assembler
    Copyright (C) 2002 Toby Thain, toby@telegraphics.com.au

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by  
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License  
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "asm.h"

extern char *class_sh[],*class_c[];

void disasm(char *s,int word){
	if(word>>15){
		char *skips[]={"   ","SKP","SZC","SNC","SZR","SNR","SEZ","SBN"};
		/* two accumulator - multiple operation */
		/*			          | | | | | | | | | | | | | | | | | */
		sprintf(s,"2AC: |1| %o | %o |  %o  | %1s | %1s |%c| %s |",
			(word>>13)&3,(word>>11)&3,(word>>8)&7,
			class_sh[(word>>6)&3],class_c[(word>>4)&3],word&010?'#':' ',skips[word&7]);
	}else{
		if((word>>13)&3 == 3) /* input/output */
		/*		               | | | | | | | | | | | | | | | | | */
			sprintf(s,"I/O: |0 1 1| %o |  %o  | %o |    %02o     |",
				(word>>11)&3,(word>>8)&7,(word>>6)&3,word&077);
		else /* one accumulator - effective address */	
			sprintf(s,"%cAC: |0| %o | %o |%c| %o |      %03o      |",
				'0'+((word>>13)!=0),
				(word>>13)&3,(word>>11)&3,word&02000?'@':' ',(word>>8)&3,word&0377);
	}
}
