/*  
    This file is part of The Didactic PDP-8 Assembler
    Copyright (C) 2002 Toby Thain, toby@telegraphics.com.au

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by  
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License  
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "asm.h"
#include "nova.h"
#include "y.tab.h"

char target_arch[] = "DG NOVA";

#define NOAC(m,op) {0,m,op<<11,F_NOAC,0}
#define ONEAC(m,op) {0,m,op<<13,F_ONEAC,0}
#define IO(m,op,c,d) {0,m,060000|(op<<8)|(c<<6)|d,F_IO,0}
#define SYM(m,v) {0,m,v,0,0}
#define SKIP(m,v) {0,m,v,F_SKIP,0}
enum{
	DEV_STACK=01,
	DEV_CPU=077,
	DEV_MDV=01,
	DEV_RTC=014,
	DEV_PAR=04,
	DEV_MMPU=02,
	DEV_MMU=02,
	DEV_MMU1=03,
	DEV_MAP=02,
	DEV_MAP1=03,
	DEV_FPU1=074,
	DEV_FPU2=075,
	DEV_FPU=076
};

struct sym_rec predefs[] = {
	ONEAC("LDA",1),
	ONEAC("STA",2),
	IO("PSHA",3,0,DEV_STACK),
	IO("POPA",3,2,DEV_STACK),
	IO("SAV", 5,0,DEV_STACK),
	IO("MTSP",2,0,DEV_STACK),
	IO("MTFP",0,0,DEV_STACK),
	IO("MFSP",2,2,DEV_STACK),
	IO("MFFP",0,2,DEV_STACK),
	IO("RET", 5,2,DEV_STACK),
	NOAC("JMP",0),
	NOAC("JSR",1),
	NOAC("ISZ",2),
	NOAC("DSZ",3),
	{0,"TRAP",0100010,F_TRAP|F_ASSIGNED,0}, /* a special 2-ac instruction */
	IO("INTEN",0,1,DEV_CPU),
	IO("INTDS",0,2,DEV_CPU),
	IO("READS",1,0,DEV_CPU),/*not sure what implicit F should be for these? */
	IO("INTA", 3,0,DEV_CPU),
	IO("MSKO", 4,0,DEV_CPU),
	IO("IORST",5,0,DEV_CPU),
	IO("HALT", 6,0,DEV_CPU),
	IO("MUL",026,3,DEV_MDV),
	IO("DIV",026,1,DEV_MDV),
	IO(".FLDS",4,3,DEV_FPU1),
	IO(".FLDD",4,3,DEV_FPU2),
	IO(".FSRS",4,1,DEV_FPU1),
	IO(".FSRD",4,1,DEV_FPU2),
	IO(".FAS",2,0,DEV_FPU1),
	IO(".FAD",2,0,DEV_FPU2),
	IO(".FSS",2,1,DEV_FPU1),
	IO(".FSD",2,1,DEV_FPU2),
	IO(".FMS",2,3,DEV_FPU1),
	IO(".FMD",2,3,DEV_FPU2),
	IO(".FDS",2,2,DEV_FPU1),
	IO(".FDD",2,2,DEV_FPU2),
	IO(".FMFT",0,3,DEV_FPU2),
	IO(".FMTF",0,2,DEV_FPU2),
	IO(".FATS",6,0,DEV_FPU1),
	IO(".FATD",6,0,DEV_FPU2),
	IO(".FSTS",6,1,DEV_FPU1),
	IO(".FSTD",6,1,DEV_FPU2),
	IO(".FMTS",6,3,DEV_FPU1),
	IO(".FMTD",6,3,DEV_FPU2),
	IO(".FDTS",6,2,DEV_FPU1),
	IO(".FDTD",6,2,DEV_FPU2),
	IO(".FABS",0,3,DEV_FPU1),
	IO(".FCLR",0,1,DEV_FPU1),
	IO(".FLDX",4,2,DEV_FPU2),
	IO(".FNEG",0,2,DEV_FPU1),
	IO(".FNRM",0,1,DEV_FPU2),
	IO(".FHWD",1,0,DEV_FPU1),
	IO(".FSCL",4,0,DEV_FPU2),
	IO(".FRST",1,2,DEV_FPU),
	IO(".FWST",2,0,DEV_FPU),
	IO(".",2,0,DEV_FPU),
/* the following are simply constants */
/* special skip qualifier symbols (two accumulator instructions) */
	SKIP("SKP",1),
	SKIP("SZC",2),
	SKIP("SNC",3),
	SKIP("SZR",4),
	SKIP("SNR",5),
	SKIP("SEZ",6),
	SKIP("SBN",7),
/* device code constants (I/O instructions) */
	SYM("CPU", 077),
	SYM("MDV", 001),
	SYM("RTC", 014),
	SYM("PAR", 004),
	SYM("MMPU",002),
	SYM("MMU", 002),
	SYM("MMU1",003),
	SYM("MAP", 002),
	SYM("MAP1",003),
	SYM("FPU1",074),
	SYM("FPU2",075),
	SYM("FPU", 076),
	{0,0,0,0,0}
};

composite(char *mnemonic,char *s1,char *s2,int op,int f){
	struct sym_rec *s;
	char mn[20],*q;

	NEW(s);
	/* form composite mnemonic by adding suffixes */
	q = scpy(mn,mnemonic);
	q = scpy(q,s1);
	scpy(q,s2);
	s->name = sdup(mn);
	s->value = op;
	s->flags = f|F_ASSIGNED;
	if(debug && lookup(mn))
		printf("!!!!! duplicate predefined symbol: %s (composite mnemonic)\n",mn);
	insert(s);
	/*DPRINTF("# 2 ac instruction: %-5s %#o\n",s->name,s->value);*/
}

char *class_c[]  = {"","Z","O","C",0},
	 *class_sh[] = {"","L","R","S",0},
	 *class_f[]  = {"","S","C","P",0},
	 *class_t[]  = {"BN","BZ","DN","DZ",0},
	 *twoac_op[8],*io_op[8],*noac_op[4],*oneac_op[4],*skips[8];

iodata(char*mnemonic,int opcode,char **class){
	char **fsuf,*p;
	int f;
	io_op[opcode] = mnemonic;
	for(fsuf=class,f=0;*fsuf;f++,fsuf++)
		composite(mnemonic,*fsuf,"",060000|(opcode<<8)|(f<<6),F_IO);
}

twoac(char*mnemonic,int opcode){
	char **csuf,**shsuf,*q;
	int c,sh;
	twoac_op[opcode] = mnemonic;
	for(csuf=class_c,c=0;*csuf;c++,csuf++)
		for(shsuf=class_sh,sh=0;*shsuf;sh++,shsuf++)
			composite(mnemonic,*csuf,*shsuf,0100000|(opcode<<8)|(sh<<6)|(c<<4),F_TWOAC);
}

cpu_initsyms(){
	struct sym_rec *p;

	twoac("COM",0);
	twoac("NEG",1);
	twoac("MOV",2);
	twoac("INC",3);
	twoac("ADC",4);
	twoac("SUB",5);
	twoac("ADD",6);
	twoac("AND",7);

	iodata("NIO",0,class_f);
	iodata("DIA",1,class_f);
	iodata("DOA",2,class_f);
	iodata("DIB",3,class_f);
	iodata("DOB",4,class_f);
	iodata("DIC",5,class_f);
	iodata("DOC",6,class_f);
	iodata("SKP",7,class_t);

	skips[0] = "   ";
	for(p=predefs;p->name;++p)
		if(p->flags & F_NOAC) 
			noac_op[(p->value>>11)&3] = p->name;
		else if(p->flags & F_ONEAC) 
			oneac_op[(p->value>>13)&3] = p->name;
		else if(p->flags & F_SKIP)
			skips[p->value] = p->name;
}
