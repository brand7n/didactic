#include "asm.h"

/* return pointer after last character of string */
char *endof(char *s){
	while(*s)
		++s;
	return s;
}
/* copy string; return pointer after last char copied */
char *cat(char *dst,char *s){
	while(*dst = *s++)
		++dst;
	return dst;
}
