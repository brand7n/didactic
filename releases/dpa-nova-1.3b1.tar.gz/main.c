/*  
    This file is part of The Didactic PDP-8 Assembler
    Copyright (C) 2002 Toby Thain, toby@telegraphics.com.au

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by  
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License  
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "asm.h"

extern int yydebug;
int debug = 0,pass,interactive = 0,verbose = 0;
char default_out[] = "dpa.out",
	 version[] = "1.3b1";

void makepass(int p,char *fn,FILE *fp){
	pass = p;
	curloc = 0200;
	words = 0;
	radix = 8;
	lineno = 1;
	yyrestart(fp);
	yyparse();
	DPRINTF("=== pass %d complete\n\n",p);
	if(p==2){
		if(verbose) dump_symbols();
		VPRINTF("# %s : %d errors, %d words\n",fn,errors,words);
	}
}

void banner(){
	printf("%s Assembler %s, Copyright (C) 2002 Toby Thain\n\n",target_arch,version);
}

void usage(char *s){
	printf("usage: %s [OPTION]... [FILE]...\n\
       -d : debug mode (trace parsing etc.)\n\
       -r : produce RIM-format output file\n\
            (default output format is BIN)\n\
       -p : punch 2' lead-in and lead-out\n\
       -v : be verbose (show object as it is generated, and dump symbol table)\n\
       -w : show warranty\n\
       -c : show copyright\n\
       -h : show this help\n\
Invoke with no files to use interactively.\n",s);
}

int main(int argc,char*argv[]){
	int i,result,nfiles=0;
	FILE *fp;

	init_symtab();

	for(i=1;i<argc;i++)
		if(*argv[i] == '-'){
			switch((argv[i])[1]){
			case 'd': debug = 1; break;
			case 'r': rimflag = 1; break;
			case 'p': leader = 1; break;
			case 'v': verbose = 1; break;
			case 'w': banner(); warranty(); return EXIT_SUCCESS;
			case 'c': banner(); copyright(); return EXIT_SUCCESS;
			case 'h': banner(); usage(argv[0]); return EXIT_SUCCESS;
			default:
				banner();
				printf("unrecognised option; try \"%s -h\" for more information.\n",argv[0]);
				return EXIT_FAILURE;
			}
		}else
			++nfiles;

	if(nfiles){
		if(verbose) banner();
		for(i=1;i<argc;i++)
			if(*argv[i] != '-')
				if(fp = fopen(argv[i],"r")){
					VPRINTF("--- input: %s\n",argv[i]);
					errors = 0;

					obj = 0;
					makepass(1,argv[i],fp);
					if(errors){
						fprintf(stderr,"# assembly aborted; skipping pass 2\n");
					}else{
						open_out(argv[i]);
						/* do pass 2 */
						rewind(fp);
						makepass(2,argv[i],fp);
						close_out();
					}
					clean_syms();
					fclose(fp);
				}else
					fprintf(stderr,"# can't open \"%s\"\n",argv[i]);
	}else{
		interactive = 1;
		banner();
		puts("This software comes with ABSOLUTELY NO WARRANTY; for details run with option -w.\n\
This is free software, and you are welcome to redistribute it\n\
under certain conditions; run with option -c for details.\n");
		puts("no files specified; running interactively on standard input (single pass)\n\
WARNING: all forward symbol references will be incorrect!");
		init_symtab();
		open_out("dpa.out");
		makepass(2,"<stdin>",stdin);
		close_out();
		/*clean_syms();*/
	}
	return EXIT_SUCCESS;
}

