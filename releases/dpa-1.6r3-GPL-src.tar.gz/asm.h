/*  
    This file is part of The Didactic PDP-8 Assembler
    Copyright (C) 2002 Toby Thain, toby@telegraphics.com.au

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by  
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License  
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern char version[],target_arch[],
            listfmt[],listfmt_noloc[],listfmt_empty[];

/* #define NULL ((void*)0) */
#define NEW(P) ( (P) = malloc(sizeof(*(P))) )

#define VPUTS if(verbose) puts
#define VPRINTF if(verbose) printf
#define DPUTS if(debug) puts
#define DPRINTF if(debug) printf

enum{ /* symbol flags */
	F_NONE = 0,
	F_USER=01, /* symbol was user-created rather than built-in */
	F_ASSIGNED=02, /* symbol has been given a value */
};

struct sym_rec{
	struct sym_rec *next;
	char *name;
	int value,token,flags,lineno;
};

extern struct sym_rec predefs[],*lastsym;
extern int casesense,rimflag,leader,
	errors,pass,lineno,debug,interactive,verbose,
	radix,curloc,words;
extern FILE *obj;

void yyerror(char*s);
extern yyparse();

struct sym_rec *lookup(char *s);
void init_symtab();
void insert(struct sym_rec *p);
void expunge();
void clean_syms();

#define fatal yyerror
void warning(char *s);

void assemble(int word);
void setorg(int loc);
void dump_object(void);

void keepassign(struct sym_rec *p);
void doassigns(int value,int flags);
void doassign(struct sym_rec *p,int value,int flags);

int mri(int opcode,int mod,int operand);
int combine(int op1,int op2);

char *scpy(char *dst,char *s);
char *sdup(char*);
char *uppercase(char*);
char *endof(char *str);
int read_num(char *p,int radix);
int read_signed(char *p,int radix);

void microinst(char *s,int word,char *codes[]);
void disasm(char *s,int word);

void header();
void footer();
void putout(int loc,int val);
void open_out(char *fn);
void close_out();

void warranty();
void copyright();

void dolisting(int act,int leng,char *text);
void listo(int a,int w);
void newline(void);
void flushlist(void);
