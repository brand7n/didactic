#include "asm.h"

#define MAXASSIGNS 10
struct sym_rec *assignstack[MAXASSIGNS];
int assigncount = 0;

void definelabel(struct sym_rec *p){ 
	if(p->flags & F_ASSIGNED)
		warning("label already defined; ignoring this definition");
	else{
		p->value = curloc; 
		if(pass==2)
			p->flags |= F_ASSIGNED;
		DPRINTF("-- define label \"%s\" = %#o\n",p->symbol,curloc); 
	}
}

void keepassign(struct sym_rec *p){ 
	if(assigncount==MAXASSIGNS)
		warning("too many cascaded assignments - some ignored");
	else
		assignstack[assigncount++] = p; 
}

void doassigns(int v){ 
	struct sym_rec *p;
	for(;assigncount;){
		p = assignstack[--assigncount];
		if(p->flags & F_ASSIGNED)
			warning("symbol redefined");
		p->value = v;
		p->flags |= F_ASSIGNED;
		DPRINTF(" (assign %#o to \"%s\")\n", p->value, p->symbol);
	}
}
