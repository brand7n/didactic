#include "asm.h"

void err(char *kind,char *text)
{
	fprintf(stderr,"# %s pass %d @ line %d (object address %#o): %s\n",
		kind,pass,lineno,curloc,text);
}
void yyerror(char *s){
	err("ERROR",s);
}
void warning(char *s){
	err("WARNING",s);
}
