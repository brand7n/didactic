#include "asm.h"

int mri(int opcode,int ind,int zp,int addr){
	int page = addr & ~PAGE_ADDR,
	    curpage = curloc & ~PAGE_ADDR;
	DPRINTF("MRI(%#o,ind=%d,zp=%d,addr=%#o) page=%#o curpage=%#o\n",
		opcode,ind,zp,addr,page,curpage);
	if(page!=0){
		if(zp)
			warning("conflicting use of zero page modifier");
		opcode |= CURR_PAGE;
		if(page != curpage)
			warning("illegal out-of-page reference");
	}
	if(ind)
		opcode |= INDIRECT_MODE;
	return opcode | (addr & PAGE_ADDR);
}
