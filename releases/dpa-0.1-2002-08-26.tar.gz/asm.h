#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* #define NULL ((void*)0) */
#define NEW(P) ( (P) = malloc(sizeof(*(P))) )

#define WORDMASK 07777 /* words are 12 bits */

/* instruction bit masks */
enum{
	OPCODE = 07000,
	/* microcoded instructions */
	GROUP_BIT = 0400,
	REVERSE_SENSE = 010,
	/* memory reference instructions */
	PAGE_ADDR = 0177,
	CURR_PAGE = 0200,
	INDIRECT_MODE = 0400
};

#define DPUTS if(debug) puts
#define DPRINTF if(debug) printf

/* values to differentiate pseudo-ops */
enum{ 
	V_FIELD=1,V_EXPUNGE,V_FIXMRI,V_PAUSE,V_FIXTAB,V_DECIMAL,V_OCTAL 
};

enum{ F_USER=01,F_ASSIGNED=02 };
struct sym_rec{
	struct sym_rec *next;
	char *symbol;
	int token,value,flags;
};

extern struct sym_rec predefs[],*lastsym;
extern int pass,lineno,debug,radix,curloc,object[],lastnum;

int read_num(char *str,int radix);
void yyerror(char*s);
extern yyparse();

struct sym_rec *lookup(char *s);

void init_symtab();
void insert(struct sym_rec *p);

#define fatal yyerror
void warning(char *s);

void assemble(int word);
void dump_object(void);

void keepassign(struct sym_rec *p);
void doassigns(int value);

int mri(int opcode,int ind,int zp,int operand);

void microinst(char *s,int word,char *codes[]);
void disasm(char *s,int word);
