#include "asm.h"
#include "fnv/fnv.h"

/* following constant should be prime. for a list of prime numbers, 
   see http://www.utm.edu/research/primes/lists/small/1000.txt */
#define TABLE_SIZE_PRIME 509
#define HASH(s) (fnv_32_str(s,FNV1_32_INIT) % TABLE_SIZE_PRIME)

struct sym_rec *hash_table[TABLE_SIZE_PRIME];

void init_symtab(){
	struct sym_rec *p;
	int i;

	for(i=TABLE_SIZE_PRIME;i--;)
		hash_table[i] = 0;
	for(p=predefs;p->symbol;p++)
		insert(p);
}

void dump_symbols(){
	struct sym_rec *p;
	int i;
	puts("\nsymbol table:");
	for(i=0;i<TABLE_SIZE_PRIME;i++)
		if(hash_table[i]){
			for(p=hash_table[i];p;p=p->next)
				if(p->flags & F_USER){
					printf("%8s",p->symbol);
					if(p->flags & F_ASSIGNED)
						printf(" = %#o\n",p->value);
					else
						printf(" (unassigned)\n");
				}
		}
}

/*
char *strdup(char *s){
	char *p = malloc(strlen(s)+1);
	strcpy(p,s);
	return p;
}
*/

struct sym_rec *lookup(char *s){
	struct sym_rec *p;
	int idx = HASH(s);
	if(0)
		printf("# lookup \"%s\" hash=%5d\n",s,idx);
	for(p=hash_table[idx];p;p=p->next)
		if(!strcmp(s,p->symbol))
			return p;
	return 0; /* not found */
}
void insert(struct sym_rec *p){
	int idx = HASH(p->symbol);
	p->next = hash_table[idx];
	hash_table[idx] = p;
	if(0)
		printf("# insert symbol [%5d] \"%s\"\n",idx,p->symbol);
}
