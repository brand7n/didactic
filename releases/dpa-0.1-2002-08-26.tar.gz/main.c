#include "asm.h"

int debug = 0,pass;

int read_num(char *p,int radix)
{
	int acc,sign=1;
/* for now, numbers are always positive
	if(*p == '-'){
		sign = -1;
		++p;
	}
*/
	for(acc=0;isdigit(*p);){
		acc *= radix;
		acc += (*p++) - '0';
	}
	return sign*acc;
}

process(char *name,FILE *fp,int dopass){
	printf("--- %s ---\n",name);
	curloc = 0200;
	radix = 8;
	init_symtab();
	for(pass=dopass;pass<=2;pass++){
		if(fp != stdin) rewind(fp);
		yyrestart(fp);
		lineno = 1;
		yyparse();
	}
	/* dump_object(); */
	dump_symbols();
	if(fp != stdin) fclose(fp);
}

int main(int argc,char*argv[]){
	int i,result,nfiles=0;
	FILE *fp;

	for(i=1;i<argc;i++)
		if(*argv[i] == '-'){
			if((argv[i])[1] == 'd') debug = 1;
		}else
			++nfiles;
	if(nfiles){
		for(i=1;i<argc;i++)
			if(*argv[i] != '-')
				if(fp = fopen(argv[i],"r"))
					process(argv[i],fp,1);
				else
					fprintf(stderr,"# can't open \"%s\"\n",argv[i]);
	}else{
		puts("no files; processing standard input (single pass)");
		puts("all forward symbol references will be incorrect!");
		process("<stdin>",stdin,2);
	}
	return EXIT_SUCCESS;
}

