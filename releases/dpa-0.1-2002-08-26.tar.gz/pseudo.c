#include "asm.h"

void pseudo(struct sym_rec *p){
	switch(p->value){
/*
	case V_FIELD: break;
	case V_EXPUNGE: break;
	case V_FIXMRI: break;
	case V_PAUSE: break;
	case V_FIXTAB: break;
*/
	case V_DECIMAL: radix = 10; if(debug) puts(" radix now decimal"); break;
	case V_OCTAL: radix = 8; if(debug) puts(" radix now octal"); break;
	default: warning("unimplemented pseudo-instruction");
	}
}
