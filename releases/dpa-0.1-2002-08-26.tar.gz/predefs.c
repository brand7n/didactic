#include "asm.h"
#include "y.tab.h"

#define PSEUDO(S,V)	{NULL,S,TOK_DIR,V,0}
#define MRI(S,V)	{NULL,S,TOK_MRI,V,0}
#define NONMRI(S,V)	{NULL,S,TOK_NONMRI,V,0}

struct sym_rec predefs[] = {
	/* pseudo instructions */
	PSEUDO("FIELD",V_FIELD),
	PSEUDO("EXPUNGE",V_EXPUNGE),
	PSEUDO("FIXMRI",V_FIXMRI),
	PSEUDO("PAUSE",V_PAUSE),
	PSEUDO("FIXTAB",V_FIXTAB),
	PSEUDO("DECIMAL",V_DECIMAL),
	PSEUDO("OCTAL",V_OCTAL),

	/* memory reference instructions */
	MRI("AND",00000),
	MRI("TAD",01000),
	MRI("ISZ",02000),
	MRI("DCA",03000),
	MRI("JMS",04000),
	MRI("JMP",05000),

	/* floating point instructions */
	MRI("FEXT",00000),
	MRI("FADD",01000),
	MRI("FSUB",02000),
	MRI("FMPY",03000),
	MRI("FDIV",04000),
	MRI("FGET",05000),
	MRI("FPUT",06000),
	MRI("FNOR",07000),

	/* group 1 operates */
	NONMRI("NOP",07000),
	NONMRI("IAC",07001),
	NONMRI("RAL",07004),
	NONMRI("RTL",07006),

	NONMRI("RAR",07010),
	NONMRI("RTR",07012),
	NONMRI("CML",07020),
	NONMRI("CMA",07040),
	NONMRI("CLL",07100),
	NONMRI("CLA",07200),

	/* group 2 operates */
	NONMRI("HLT",07402),
	NONMRI("OSR",07404),

	/* combined operates */
	NONMRI("CIA",07041),
	NONMRI("LAS",07604),
	NONMRI("SKP",07410),
	NONMRI("SNL",07420),
	NONMRI("SZL",07430),
	NONMRI("SZA",07440),
	NONMRI("SNA",07450),
	NONMRI("SMA",07500),
	NONMRI("SPA",07510),
	NONMRI("STL",07120),
	NONMRI("GLK",07204),
	NONMRI("STA",07240),

	{NULL} /* mark end of table */
};
