#include "asm.h"
#include "y.tab.h"

#define MAXASSIGNS 10
struct sym_rec *assignstack[MAXASSIGNS];
int assigncount = 0;

void definelabel(struct sym_rec *p){ 
	if( pass==1 && (p->flags & F_ASSIGNED) )
		warning("label already defined; ignoring this definition");
	else{
		p->value = curloc; 
		p->flags |= F_ASSIGNED;
		DPRINTF("-- define label \"%s\" = %#o\n",p->name,curloc); 
	}
}

void keepassign(struct sym_rec *p){ 
	if(assigncount==MAXASSIGNS)
		warning("too many cascaded assignments - some ignored");
	else
		assignstack[assigncount++] = p; 
}

void doassigns(int v,int f){ 
	struct sym_rec *p;
	for(;assigncount;)
		doassign(assignstack[--assigncount],v,f);
}
void doassign(struct sym_rec *p,int v,int f){ 
	if(p->flags & F_ASSIGNED)
		warning("symbol redefined");
	p->value = v;
	p->flags |= f | F_ASSIGNED;
	DPRINTF(" ( %s <- %#o )\n",p->name,p->value);
}
