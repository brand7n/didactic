#include "asm.h"

extern int yydebug;
int debug = 0,pass;

makepass(){
	curloc = 0200;
	radix = 8;
	lineno = 1;
	yyparse();
}

int main(int argc,char*argv[]){
	int i,result,nfiles=0;
	FILE *fp;

	/*yydebug = 1;*/

	for(i=1;i<argc;i++)
		if(*argv[i] == '-'){
			if((argv[i])[1] == 'd') debug = 1;
		}else
			++nfiles;
	if(nfiles){
		for(i=1;i<argc;i++)
			if(*argv[i] != '-')
				if(fp = fopen(argv[i],"r")){
					printf("--- %s ---\n",argv[i]);
					init_symtab();
					errors = 0;
					for(pass=1;pass<=2;++pass){
						yyrestart(fp);
						makepass();
						if(errors){
							fprintf(stderr,"## assembly aborted\n");
							break;
						}
						rewind(fp);
					}
					dump_symbols();
					fclose(fp);
				}else
					fprintf(stderr,"# can't open \"%s\"\n",argv[i]);
	}else{
		puts("no files; using standard input (single pass)");
		puts("WARNING: all forward symbol references will be incorrect!");
		pass = 2;
		init_symtab();
		makepass();
		dump_symbols();
	}
	return EXIT_SUCCESS;
}

