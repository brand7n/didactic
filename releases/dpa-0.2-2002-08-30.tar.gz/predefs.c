#include "asm.h"
#include "y.tab.h"

/* #define PSEUDO(S,V)	{NULL,S,TOK_DIR,V,F_ASSIGNED,0}*/
#define MRI(S,V)	{NULL,S,V,F_ASSIGNED|F_MRI}
#define NONMRI(S,V,seq)	{NULL,S,V,F_ASSIGNED}

struct sym_rec predefs[] = {
#if 0
	/* pseudo instructions */
	PSEUDO("FIELD",V_FIELD),
	PSEUDO("EXPUNGE",V_EXPUNGE),
	/*PSEUDO("FIXMRI",V_FIXMRI),*/ /*actually impl as token*/
	PSEUDO("PAUSE",V_PAUSE),
	PSEUDO("FIXTAB",V_FIXTAB),
	PSEUDO("DECIMAL",V_DECIMAL),
	PSEUDO("OCTAL",V_OCTAL),
#endif

	/* memory reference instructions */
	MRI("AND",00000),
	MRI("TAD",01000),
	MRI("ISZ",02000),
	MRI("DCA",03000),
	MRI("JMS",04000),
	MRI("JMP",05000),

	/* floating point instructions */
	MRI("FEXT",00000),
	MRI("FADD",01000),
	MRI("FSUB",02000),
	MRI("FMPY",03000),
	MRI("FDIV",04000),
	MRI("FGET",05000),
	MRI("FPUT",06000),
	MRI("FNOR",07000),

	/* group 1 operates */
	NONMRI("NOP",07000,NOSEQ),
	NONMRI("IAC",07001,3),
	NONMRI("RAL",07004,4),
	NONMRI("RTL",07006,4),

	NONMRI("RAR",07010,4),
	NONMRI("RTR",07012,4),
	NONMRI("CML",07020,2),
	NONMRI("CMA",07040,2),
	NONMRI("CLL",07100,1),
	NONMRI("CLA",07200,1),

	/* group 2 operates */
	NONMRI("HLT",07402,3),
	NONMRI("OSR",07404,3),

	/* combined operates */
	NONMRI("CIA",07041,NOSEQ),
	NONMRI("LAS",07604,NOSEQ),
	NONMRI("SKP",07410,1),
	NONMRI("SNL",07420,1),
	NONMRI("SZL",07430,1),
	NONMRI("SZA",07440,1),
	NONMRI("SNA",07450,1),
	NONMRI("SMA",07500,1),
	NONMRI("SPA",07510,1),
	NONMRI("STL",07120,NOSEQ),
	NONMRI("GLK",07204,NOSEQ),
	NONMRI("STA",07240,NOSEQ),

	{NULL} /* mark end of table */
};
