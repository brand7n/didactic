#include "asm.h"

#define MAX_OBJECT 4096

int curloc, radix, object[MAX_OBJECT];


void assemble(int word){
	char s[200];
	if(curloc == MAX_OBJECT)
		fatal("at end of object space");
	else{
		if(pass==2){
			/* if(curloc<lwm) lwm = curloc;
			if(curloc>hwm) hwm = curloc; */
			disasm(s,word);
			printf("[%04o] = %04o   %s\n", curloc,word,s);
			object[curloc] = word;
		}
		++curloc;
	}
}
/*
void dump_object(){
	int i;

	puts("\nobject code:");
	for(i=lwm;i<=hwm;i++)
		printf("%04o = %04o\n",i,object[i]);
}
*/
