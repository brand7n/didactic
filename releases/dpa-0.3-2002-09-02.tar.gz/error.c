#include "asm.h"

int errors;

void err(char *kind,char *text)
{
	fprintf(stderr,"# %s pass %d, line %d @ %#o: %s\n",
		kind,pass,lineno,curloc,text);
}
void yyerror(char *s){
	++errors;
	err("ERROR",s);
}
void warning(char *s){
	err("WARNING",s);
}
