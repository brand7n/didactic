#include "asm.h"

char *opcodes[]={"AND","TAD","ISZ","DCA","JMS","JMP"},
     *vopcodes[]={"logical AND","2's complement ADD","increment & skip if 0","deposit & clear AC","jump to subroutine","jump"},
     *group1[]={"CLA","CLL","CMA","CML","RAR","RAL","x2","IAC"},
     *vgroup1[]={"clear AC","clear L","complement AC","complement L","rotate AC,L right","rotate AC,L left","(rotate twice)","increment AC"},
     *group2_0[]={"CLA","SMA","SZA","SNL","---","OSR","HLT","---"},
     *vgroup2_0[]={"clear AC","skip on AC<0","skip on AC==0","skip on L!=0","---","OR switch reg with AC","halt","---"},
     *group2_1[]={"CLA","SPA","SNA","SZL",""/*SKP?*/,"OSR","HLT","---"},
     *vgroup2_1[]={"clear AC","skip on AC>=0","skip on AC!=0","skip on L==0",""/*SKP?*/,"OR switch reg with AC","halt","---"};

void microinst(char *s,int word,char *codes[]){
	int mask,i;
	for(mask=0200,i=0;mask;mask>>=1,++i)
		if(word & mask){
			strcat(s," ");
			strcat(s,codes[i]);
		}
}

void disasm(char *s,int word){
	int op = word >> 9,ea;
	if(op<6){ /* memory reference instruction */

		/* compute effective address */
		ea = word & PAGE_ADDR;
		if(word & CURR_PAGE)
			ea |= curloc & ~PAGE_ADDR;

		sprintf(s,"memref: %s %c %c %03o (addr=%04o)",
			opcodes[op],
			word & INDIRECT_MODE ? 'I' : ' ',
			word & CURR_PAGE ? ' ' : 'Z',
			word & PAGE_ADDR, ea );
	}else if(op==7){
		if(word & GROUP_BIT){ /* group 2 microinstruction */
			strcpy(s,"group2:");
			microinst(s,word,word & REVERSE_SENSE ? group2_1 : group2_0);
			if((word & REVERSE_SENSE) && !(word & SKIPS))
				strcat(s," SKP");
		}else{ /* group 1 microinstruction */
			strcpy(s,"group1:");
			microinst(s,word,group1);
		}
	}else strcpy(s," --disasm not impl yet--");
}
