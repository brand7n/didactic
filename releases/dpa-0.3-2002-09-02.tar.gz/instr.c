#include "asm.h"

int mri(int opcode,int ind,int zp,int addr){
	int page = addr & ~PAGE_ADDR,
	    curpage = curloc & ~PAGE_ADDR;
	DPRINTF("MRI(%#o,ind=%d,zp=%d,addr=%#o) page=%#o curpage=%#o\n",
		opcode,ind,zp,addr,page,curpage);
	if(page!=0){
		if(zp)
			warning("conflicting use of zero page modifier?");
		opcode |= CURR_PAGE;
		if(page != curpage)
			warning("illegal out-of-page reference");
	}
	if(ind)
		opcode |= INDIRECT_MODE;
	return opcode | (addr & PAGE_ADDR);
}

#define ISCLA(op) ((op & ~GROUP_BIT) == 07200)
#define ISSKP(op) (!(op & SKIPS) && (op & REVERSE_SENSE))
#define DIFFGROUPS(op1,op2) ((op1 ^ op2) & GROUP_BIT)

int combine(int op1,int op2){ /* combine non-memory reference instructions */
	if((op1&OPCODE)==OPCODE_OPR && (op2&OPCODE)==OPCODE_OPR){
		/* are opcodes from different groups? */
		if(DIFFGROUPS(op1,op2)){
			/* special case CLA, it is in both groups */
			if(ISCLA(op1)) 
				op1 ^= GROUP_BIT;
			else if(ISCLA(op2)) 
				op2 ^= GROUP_BIT;
			else
				fatal("can't combine microinstructions from different groups");
		}
		if(!DIFFGROUPS(op1,op2)){
			if(op1 & GROUP_BIT){
				/* group 2: check for incompatible skips: */
			    if( ( (op1 & SKIPS) && (op2 & SKIPS) /* both conditional */
				  && ((op1^op2) & REVERSE_SENSE) ) /* and different senses */
				|| ( ((op1|op2) & SKIPS) /* or, either is conditional */
				     && (ISSKP(op1) || ISSKP(op2)) ) ) /* and one is unconditional */
				fatal("can't combine these skips");
			}else{
				/* group 1: are both rotates? */
				if( (op1 & ROTATES) && (op2 & ROTATES) )
					fatal("can't combine rotates");
			}
		}
	}else if((op1&OPCODE)==OPCODE_IOT && (op2&OPCODE)==OPCODE_IOT){
		if((op1&DEVICE_SELECT) != (op2&DEVICE_SELECT))
			fatal("can't combine IOTs on different devices");
	}else fatal("can't combine memory-reference instructions)");
	return op1 | op2;
}
