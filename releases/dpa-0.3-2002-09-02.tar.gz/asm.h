#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* #define NULL ((void*)0) */
#define NEW(P) ( (P) = malloc(sizeof(*(P))) )

#define WORDMASK 07777 /* words are 12 bits */

/* instruction bit masks */
enum{
	OPCODE = 07000,
	/* microcoded instructions */
	GROUP_BIT = 0400,
	REVERSE_SENSE = 010,
	/* memory reference instructions */
	PAGE_ADDR = 0177,
	CURR_PAGE = 0200,
	INDIRECT_MODE = 0400,
	ROTATES = 014, /* group 1 rotates */
	SKIPS = 0160, /* group 2 skips */
	/* IOT microinstructions */
	DEVICE_SELECT = 0770
};
enum{ 
	OPCODE_IOT = 06000,
	OPCODE_OPR = 07000
};

#define DPUTS if(debug) puts
#define DPRINTF if(debug) printf

enum{ F_USER=01,F_ASSIGNED=02,F_MRI=04 };
struct sym_rec{
	struct sym_rec *next;
	char *name;
	int value,flags;
};

extern struct sym_rec predefs[],*lastsym;
extern int errors,pass,lineno,debug,radix,curloc,object[],lastnum;

void yyerror(char*s);
extern yyparse();

struct sym_rec *lookup(char *s);

void init_symtab();
void insert(struct sym_rec *p);
void expunge();

#define fatal yyerror
void warning(char *s);

void assemble(int word);
void dump_object(void);

void keepassign(struct sym_rec *p);
void doassigns(int value,int flags);
void doassign(struct sym_rec *p,int value,int flags);

int mri(int opcode,int ind,int zp,int operand);
int combine(int op1,int op2);

void microinst(char *s,int word,char *codes[]);
void disasm(char *s,int word);
