/*  
    This file is part of The Didactic PDP-8 Assembler
    Copyright (C) 2002 Toby Thain, toby@telegraphics.com.au

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by  
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License  
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "asm.h"
#include "nova/rb.h"

/* Portions from pal.c "a 2 pass PDP-8 pal-like assembler",
   by:  Douglas Jones, Rich Coon, Bernhard Baehr 
   see http://www.cs.uiowa.edu/~jones/pdp8/
   (used with permission)
*/

extern int wordmask,listing; // full word bit mask for target architecture
int curloc,radix,words,cksum,rimflag = 0,leader = 0;
FILE *obj;
extern FILE *listfile;

void putleader()
/* generate 2 feet of leader on the object file, as per DEC documentation */
{
	if (obj && leader) {
		int i;
		for (i = 240 ; i-- ; )
 			fputc( 0200, obj );
	}
}

void puto(int c)
/* put one character to obj file and include it in checksum */
{
	c &= 0377;
	if(obj)
		fputc(c, obj);
	cksum += c;
}

void putorg( int loc )
{
	puto( ((loc >> 6) & 0077) | 0100 );
	puto( loc & 0077 );
}

void putout( int loc, int val )
/* put out a word of object code */
{

	if (obj != NULL) {

		if (rimflag == 1) { /* put out origin in rim mode */
			putorg( loc );
		}
		puto( (val >> 6) & 0077 );
		puto( val & 0077 );
	}
}

void header(){
	putleader();
	cksum = 0;
}

void footer(){
	if ((rimflag == 0) && (obj != NULL)) { /* checksum */
		/* for now, put out the wrong value */
		fputc( (cksum >> 6) & 0077, obj );
		fputc( cksum & 0077, obj );
	}
	putleader();
}

static RB_WORD rb_block[ RB_HEADER_WORDS + 15 ];
static int rb_count = 0,rb_blocks = 0;

void rb_putblock(RB_WORD b[],int n){
	int i,c;

	b[ RB_WORDCOUNT ] = -n; /* must be negative! */
	b[ RB_CHECKSUM ] = 0;
	for( i = c = 0 ; i < n+RB_HEADER_WORDS ; ++i )
		c += b[i];
	b[ RB_CHECKSUM ] = -c;
	rb_putwords(obj,b,n+RB_HEADER_WORDS);
	rb_count = 0;
	++rb_blocks;
}
void startrb(){
	extern int relmode; /* relocation mode currently in effect */
	rb_block[ RB_TYPE ] = REL_DATA_BLK;
	rb_block[ RB_RELFLAGS0 ] = rb_block[ RB_RELFLAGS1 ] = rb_block[ RB_RELFLAGS2 ] = 0;
	rb_block[ RB_HEADER_WORDS ] = curloc;
	setrelflag(rb_block,0,relmode);
	rb_count = 1;
}
void flushrb(){
	if(rb_count){
		DPUTS("flushing RB block...");
		rb_putblock(rb_block,rb_count);
	}
}
void rbtitle(struct sym_rec *s){
	flushrb();
	if(rb_blocks)
		warning(".TITL directive must come before assembly program");
	else{
		rb_block[ RB_TYPE ] = TITL_BLK;
		rb_block[ RB_RELFLAGS0 ] = rb_block[ RB_RELFLAGS1 ] = rb_block[ RB_RELFLAGS2 ] = 0;
		to_radix50(s->name,rb_block+RB_HEADER_WORDS,TITLE_SYM);
		rb_block[ RB_HEADER_WORDS+2 ] = 0; /* equivalence value */
		rb_putblock(rb_block,3);
	}
}
void rbstart(int w,int m){
	flushrb();
	rb_block[ RB_TYPE ] = START_BLK;
	rb_block[ RB_RELFLAGS0 ] = rb_block[ RB_RELFLAGS1 ] = rb_block[ RB_RELFLAGS2 ] = 0;
	setrelflag(rb_block,0,m);
	rb_block[ RB_HEADER_WORDS ] = w; /* equivalence value */
	rb_putblock(rb_block,1);
}
void open_out(char *fn){
	char out[FILENAME_MAX+1];
	FILE *fp;
	char *q;
	
	strcpy(out,fn);
	/*FIXME:strip existing suffix*/
	strcat(out,rbformat ? ".rb" : (rimflag ? ".rim" : ".bin") );
	if(obj = fopen(out,"w")){
		if(verbose||interactive)
			printf("--- object output: %s\n",out);
		if(rbformat) rb_count = 0;
		else header();
	}
	strcpy(out,fn);
	/*FIXME:strip existing suffix*/
	strcat(out,".lst");
	if( listing && (listfile = fopen(out,"w")) ){
		if(verbose||interactive)
			printf("--- listing output: %s\n",out);
	}
}
void close_out(){
	if(obj){
		if(rbformat) flushrb();
		else footer();
		fclose(obj);
	}
	if(listfile) fclose(listfile);
}

	
void setorg(int loc){
	curloc = loc;
	if(pass==2){
		VPRINTF("*%o\n",loc);
		if(rbformat) flushrb();
		else if(!rimflag)
			putorg(loc);
	}
}

void assemble(int word,int m){
	char s[200];
	word &= wordmask;
	if(pass==2){
		if(verbose){
			disasm(s,word);
			printf("[%06o] = %06o (relmode=%o)  %s\n", curloc,word,m,s);
		}
		if(rbformat){
			if(!rb_count)
				startrb();
			setrelflag(rb_block,rb_count,m);
			rb_block[RB_HEADER_WORDS + rb_count++] = word;
			if(rb_count == 15)
				flushrb();
		}else
			putout(curloc,word);
		listo(curloc,word);
	}
	++curloc;
	++words;
}
